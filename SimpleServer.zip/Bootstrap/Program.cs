﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Bootstrap
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Directory.CreateDirectory(@"C:\test");
            File.Create(@"C:\test\info.txt");
            File.WriteAllText(@"C:\test\index.html", "Open ServerModifier.exe to modify this text");
            Console.WriteLine("Done!");
            Console.ReadKey();
        }
    }
}
